"""
Ubuntu installer module for the OS Autoinstaller
This module adapts the functionality from ubuntu20.py to work with the server.py application
"""
import os
import random
import string
import time
import logging
import requests

# Disable SSL warnings
requests.packages.urllib3.disable_warnings()

logger = logging.getLogger(__name__)

def generate_iso_name(user_id, version):
    """Generate a random name for the ISO file"""
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    return f"ubuntu{version}-autoinstall-{timestamp}-{user_id}.iso"

def create_ubuntu_iso(config, remote_command_func):
    """Create a custom Ubuntu ISO with automated installation"""
    # Generate ISO filename
    user_id = config.get('user_id', ''.join(random.choices(string.ascii_lowercase + string.digits, k=6)))
    version = config.get('osVersion')
    iso_filename = generate_iso_name(user_id, version)
    
    # Define remote paths
    remote_working_dir = f"/root/iso_mod_ubuntu{version}"
    remote_extract_dir = f"{remote_working_dir}/extract"
    
    # Determine source ISO based on Ubuntu version
    if version == "20":
        remote_iso_file = "/var/www/html/ubuntu-20.04.6-live-server-amd64.iso"
    elif version == "22":
        remote_iso_file = "/var/www/html/ubuntu-22.04.5-live-server-amd64.iso"
    elif version == "24":
        remote_iso_file = "/var/www/html/ubuntu-24.04-live-server-amd64.iso"
    else:
        remote_iso_file = "/var/www/html/ubuntu-20.04.6-live-server-amd64.iso"  # Default to 20.04
    
    remote_crafted_iso = f"/var/www/html/{iso_filename}"
    
    # Set up working directory
    yield f"Setting up remote working environment for Ubuntu {version}..."
    setup_cmds = [
        f"mkdir -p {remote_working_dir} {remote_extract_dir}",
        "mkdir -p /var/www/html && chmod 755 /var/www/html",
        "apt-get update && apt-get install -y p7zip-full wget xorriso"
    ]
    
    for cmd in setup_cmds:
        result = remote_command_func(cmd)
        if result is None:
            yield f"Error: Failed to execute: {cmd}"
            return
        yield f"Executed: {cmd}"
    
    # Check if ISO file exists
    check_iso_cmd = f"test -f {remote_iso_file} && echo 'exists' || echo 'not_found'"
    iso_check_result = remote_command_func(check_iso_cmd)
    
    if iso_check_result == "not_found":
        yield f"Error: Ubuntu {version} ISO file not found at {remote_iso_file}"
        yield "Attempting to download the ISO file..."
        
        # Determine download URL based on version
        if version == "20":
            download_url = "https://releases.ubuntu.com/20.04/ubuntu-20.04.6-live-server-amd64.iso"
        elif version == "22":
            download_url = "https://releases.ubuntu.com/22.04/ubuntu-22.04.5-live-server-amd64.iso"
        elif version == "24":
            download_url = "https://releases.ubuntu.com/24.04/ubuntu-24.04-live-server-amd64.iso"
        else:
            download_url = "https://releases.ubuntu.com/20.04/ubuntu-20.04.6-live-server-amd64.iso"
        
        # Download the ISO
        download_cmd = f"wget -O {remote_iso_file} {download_url}"
        yield f"Downloading ISO from {download_url}..."
        download_result = remote_command_func(download_cmd)
        
        if download_result is None:
            yield "Error: Failed to download Ubuntu ISO. Please manually place the ISO at the correct location."
            return
        
        # Verify the download
        check_again = f"test -f {remote_iso_file} && echo 'exists' || echo 'not_found'"
        if remote_command_func(check_again) == "not_found":
            yield "Error: ISO download failed or file not found after download."
            return
        
        yield "ISO file downloaded successfully."
    
    # For Ubuntu 22.04, do an extra pre-extraction cleanup to ensure we have space
    if version == "22":
        yield "Doing pre-extraction cleanup for Ubuntu 22.04..."
        
        # Remove old ISO files to free up space
        cleanup_cmds = [
            f"find /var/www/html -name 'ubuntu*-autoinstall-*.iso' -type f -mtime +1 -delete",
            f"find /tmp -name 'ubuntu*-autoinstall-*.iso' -type f -delete",
            f"rm -rf {remote_working_dir}",  # Clean up any previous extraction attempts
            f"mkdir -p {remote_working_dir} {remote_extract_dir}"
        ]
        
        for cmd in cleanup_cmds:
            remote_command_func(cmd)
            yield f"Executed cleanup: {cmd}"
    
    # Check available disk space before extraction
    space_check_cmd = f"df -h /var/www/html | tail -1 | awk '{{print $4}}'"
    available_space = remote_command_func(space_check_cmd)
    yield f"Available disk space: {available_space}"
    
    # Try to estimate if there's enough space (roughly 2x ISO size needed)
    iso_size_cmd = f"du -h {remote_iso_file} | cut -f1"
    iso_size = remote_command_func(iso_size_cmd)
    yield f"ISO file size: {iso_size}"
    
    # Extract ISO - use more verbose commands and error handling
    yield f"Extracting Ubuntu {version} ISO..."
    
    # First clear and recreate extract directory
    clear_cmd = f"rm -rf {remote_extract_dir}/* && mkdir -p {remote_extract_dir}"
    clear_result = remote_command_func(clear_cmd)
    if clear_result is None:
        yield "Error: Failed to prepare extraction directory"
        return
    yield f"Executed: {clear_cmd}"
    
    # Extract with more verbose output and error handling - more efficient syntax
    extract_cmd = f"7z x -y -bsp1 {remote_iso_file} -o{remote_extract_dir}"
    yield f"Running extraction command: {extract_cmd}"
    extract_result = remote_command_func(extract_cmd)
    
    if extract_result is None or "Error" in extract_result:
        yield f"Error extracting ISO: {extract_result}"
        yield "Attempting alternative extraction method..."
        
        # Try alternative method using loop mounting
        alt_extract_cmds = [
            f"mkdir -p /mnt/iso_temp",
            f"mount -o loop {remote_iso_file} /mnt/iso_temp",
            f"cp -r /mnt/iso_temp/* {remote_extract_dir}/",
            f"umount /mnt/iso_temp"
        ]
        
        for cmd in alt_extract_cmds:
            alt_result = remote_command_func(cmd)
            yield f"Alt extract: {cmd} - Result: {alt_result}"
            if "mount: " in str(alt_result) and "failed" in str(alt_result):
                yield "Error: Alternative extraction method failed"
                return
    
    # Set permissions
    chmod_cmd = f"chmod -R u+w {remote_extract_dir}"
    chmod_result = remote_command_func(chmod_cmd)
    if chmod_result is None:
        yield "Warning: Failed to set permissions on extracted files"
    else:
        yield f"Set permissions: {chmod_cmd}"
    
    # Handle [BOOT] folder if it exists
    boot_cmd = f"""
    if [ -d "{remote_extract_dir}/[BOOT]" ]; then
        BOOT_DEST="{remote_working_dir}/BOOT"
        rm -rf "$BOOT_DEST" 2>/dev/null
        mv "{remote_extract_dir}/[BOOT]" "$BOOT_DEST"
    fi
    """
    remote_command_func(boot_cmd)
    
    # Find GRUB and isolinux configuration files
    yield "Modifying boot configurations..."
    
    # 1. Modify GRUB configuration
    grub_file = f"{remote_extract_dir}/boot/grub/grub.cfg"
    
    # Make a backup of the original file
    remote_command_func(f"cp {grub_file} {grub_file}.backup")
    
    # Get network configuration
    cidr = config.get('cidr', '24')
    interface = "eno3"  # Default interface
    hostname = config.get('hostname', 'ubuntu-server')
    
    # Define the boot parameters - add safety checks for network parameters
    ip_address = config.get('ipAddress', '192.168.1.100')
    gateway = config.get('gateway', '192.168.1.1')
    netmask = config.get('netmask', '255.255.255.0')
    dns_server = config.get('dnsServers', '8.8.8.8').split(',')[0]
    
    # Set boot params based on version
    if version == "22":
        # For Ubuntu 22.04, network configuration is handled entirely in cloud-init
        boot_params = "quiet autoinstall ds=nocloud-net\\;s=/cdrom/server/ apt-setup/disable-components=restricted,universe,multiverse apt-setup/no_mirror=true apt-setup/use_mirror=false apt.install.security=false security=false apt-setup/security_host= curtin/install_net_sources=false network-config/disable=true installers/curtin/offline=true offline=true debug=1"
    else:
        # For Ubuntu 20.04, include IP configuration in boot params
        boot_params = f"ip={ip_address}::{gateway}:{netmask}:{hostname}:{interface}:off nameserver={dns_server} apt-setup/disable-components=restricted,universe,multiverse apt-setup/no_mirror=true apt-setup/use_mirror=false apt.install.security=false security=false apt-setup/security_host= curtin/install_net_sources=false network-config/disable=true installers/curtin/offline=true offline=true fsck.mode=skip debug=1"
    
    # Create autoinstall menu entry
    if version == "22":
        autoinstall_entry = f"""menuentry "Autoinstall Ubuntu Server" {{
    set gfxpayload=keep
    linux /casper/vmlinuz {boot_params} ---
    initrd /casper/initrd
}}
"""
    else:
        autoinstall_entry = f"""menuentry "Autoinstall Ubuntu Server" {{
    set gfxpayload=keep
    linux /casper/vmlinuz quiet autoinstall ds=nocloud-net\\;s=/cdrom/server/ {boot_params} ---
    initrd /casper/initrd
}}
"""
    
    # Create a temporary file with the new content for GRUB
    grub_script = f"""
    original_content=$(cat {grub_file})
    echo '{autoinstall_entry}' > {grub_file}
    echo "$original_content" >> {grub_file}
    """
    
    remote_command_func(grub_script)
    
    # 2. Modify isolinux configuration (txt.cfg)
    txt_cfg_file = f"{remote_extract_dir}/isolinux/txt.cfg"
    
    # Check if the txt.cfg file exists
    txt_file_exists = remote_command_func(f"test -f {txt_cfg_file} && echo 'exists' || echo 'not found'").strip()
    
    if txt_file_exists == 'exists':
        # Make a backup of the original file
        remote_command_func(f"cp {txt_cfg_file} {txt_cfg_file}.backup")
        
        # Define the autoinstall menu entry for isolinux
        isolinux_entry = f"""label autoinstall
  menu label ^Autoinstall Ubuntu Server
  kernel /casper/vmlinuz
  append file=/cdrom/preseed/ubuntu-server.seed quiet autoinstall ds=nocloud;s=/cdrom/nocloud/ {boot_params} apt-setup/disable-components=restricted,universe,multiverse apt-setup/no_mirror=true apt-setup/use_mirror=false apt.install.security=false security=false apt-setup/security_host= curtin/install_net_sources=false network-config/disable=true installers/curtin/offline=true offline=true fsck.mode=skip initrd=/casper/initrd ---
"""
        
        # Script to insert the entry and make it default
        txt_script = f"""
        # Add our entry at the top or before "label install"
        if grep -q "label install" {txt_cfg_file}; then
            sed -i 's/label install/{isolinux_entry}label install/' {txt_cfg_file}
        else
            original_content=$(cat {txt_cfg_file})
            echo '{isolinux_entry}' > {txt_cfg_file}
            echo "$original_content" >> {txt_cfg_file}
        fi
        # Make our entry the default
        if grep -q "default install" {txt_cfg_file}; then
            sed -i 's/default install/default autoinstall/' {txt_cfg_file}
        fi
        """
        
        remote_command_func(txt_script)
        
        # Make sure isolinux.cfg also has our entry as default
        isolinux_cfg_file = f"{remote_extract_dir}/isolinux/isolinux.cfg"
        isolinux_exists = remote_command_func(f"test -f {isolinux_cfg_file} && echo 'exists' || echo 'not found'").strip()
        
        if isolinux_exists == 'exists':
            isolinux_script = f"""
            # Make autoinstall the default
            if grep -q "default vesamenu.c32" {isolinux_cfg_file}; then
                sed -i 's/default vesamenu.c32/default autoinstall/' {isolinux_cfg_file}
            fi
            """
            remote_command_func(isolinux_script)
    
    # 3. Create cloud-init files
    yield "Creating cloud-init files..."
    
    # Create directories for cloud-init files
    remote_command_func(f"""
    mkdir -p {remote_extract_dir}/nocloud
    mkdir -p {remote_extract_dir}/casper/nocloud
    mkdir -p {remote_extract_dir}/server
    mkdir -p {remote_extract_dir}/preseed
    """)
    
    # Create meta-data file
    meta_data_content = f"""instance-id: ubuntu-{version}-server
local-hostname: {hostname}
"""
    
    meta_data_cmd = f"""cat > {remote_extract_dir}/nocloud/meta-data << 'EOF'
{meta_data_content}
EOF
# Copy to other locations
cp {remote_extract_dir}/nocloud/meta-data {remote_extract_dir}/casper/nocloud/meta-data
cp {remote_extract_dir}/nocloud/meta-data {remote_extract_dir}/server/meta-data
"""
    
    remote_command_func(meta_data_cmd)
    
    # Create user-data file with autoinstall config
    cidr_notation = f"{ip_address}/{cidr}"
    
    # Create different user-data based on Ubuntu version
    if version == "22":
        # Ubuntu 22.04 style user-data
        user_data = f"""#cloud-config
autoinstall:
  version: 1
  interactive-sections: []
  locale: en_US.UTF-8
  keyboard: {{layout: us}}
  timezone: Etc/UTC
  identity:
    hostname: {hostname}
    username: ubuntu
    # Set to "ubuntu" for password
    password: "$6$exDY1mhS4KUYCE/2$zmn9ToZwTKLhCw.b4/b.ZRTIZM30JZ4QrOQ2aOXJ8yk96xpcCof0kxKwuX1kqLG/ygbJ1f8wxED22bTL4F46P0"
  storage:
    layout: {{name: direct}}
  network:
    version: 2
    renderer: networkd
    ethernets:
      {interface}:
        dhcp4: false
        addresses: [{cidr_notation}]
        gateway4: {gateway}
        nameservers:
          addresses: [{dns_server}]
  apt:
    disable_components: [restricted, universe, multiverse]
    geoip: false
    preserve_sources_list: false
    primary:
      - arches: [default]
        uri: file:///cdrom
    security:
      - arches: [default]
        uri: file:///cdrom
    unattended-upgrades:
      enabled: false
  package_update: false
  package_upgrade: false
  packages: [openssh-server]
  ssh:
    install-server: true
    allow-pw: true
  drivers:
    install: false
  kernel:
    package: linux-generic
  late-commands:
    - mkdir -p /target/etc/netplan
    - chmod 755 /target/etc/netplan
    - |
      cat > /target/etc/netplan/01-netcfg.yaml << EOF
      network:
        version: 2
        renderer: networkd
        ethernets:
          {interface}:
            dhcp4: no
            addresses:
              - {cidr_notation}
            routes:
              - to: default
                via: {gateway}
            nameservers:
              addresses: [{dns_server}]
      EOF
    - chmod 644 /target/etc/netplan/01-netcfg.yaml
    - netplan apply --root=/target
"""
    else:
        # Ubuntu 20.04 style user-data (original configuration)
        user_data = f"""#cloud-config
autoinstall:
  version: 1
  early-commands:
    # Ensure autoinstall is recognized
    - mkdir -p /run/auto-install-started
    - touch /run/auto-install-started/started
    # Force the installer to work in offline mode
    - echo "APT::Get::AllowUnauthenticated \\"true\\";" > /etc/apt/apt.conf.d/99-offline
  refresh-installer:
    update: no
  locale: en_US.UTF-8
  keyboard: {{layout: us}}
  identity:
    hostname: {hostname}
    username: ubuntu
    # Password: ubuntu
    password: "$6$exDY1mhS4KUYCE/2$zmn9ToZwTKLhCw.b4/b.ZRTIZM30JZ4QrOQ2aOXJ8yk96xpcCof0kxKwuX1kqLG/ygbJ1f8wxED22bTL4F46P0"
  network:
    version: 2
    ethernets:
      {interface}:
        dhcp4: no
        addresses: [{cidr_notation}]
        gateway4: {gateway}
        nameservers:
          addresses: [{dns_server}]
  apt:
    preserve_sources_list: false
    cdrom: true
    disable_components: []
    primary: []
    # Disable all online repositories
    disable_suites: [security, updates, backports]
    # Only install what's strictly needed from the CD
  packages:
    - openssh-server
  user-data:
    disable_root: false
  timezone: UTC
  storage:
    layout:
      name: direct
  late-commands:
    # Disable apt sources that might try to reach online repositories
    - echo "# No online repositories" > /target/etc/apt/sources.list
    - echo "# CD-ROM sources only" > /target/etc/apt/sources.list.d/cdrom.list
    - mkdir -p /target/etc/netplan
    - chmod 755 /target/etc/netplan
    - |
      cat > /target/etc/netplan/01-netcfg.yaml << EOF
      network:
        version: 2
        ethernets:
          {interface}:
            dhcp4: no
            addresses:
              - {cidr_notation}
            routes:
              - to: default
                via: {gateway}
            nameservers:
              addresses: [{dns_server}]
      EOF
    - chmod 644 /target/etc/netplan/01-netcfg.yaml
    - |
      echo "network: {{config: disabled}}" > /target/etc/cloud/cloud.cfg.d/99-disable-network-config.cfg
    - |
      echo "APT::Get::AllowUnauthenticated \\"true\\";" > /target/etc/apt/apt.conf.d/99-offline
    - |
      echo "Acquire::AllowInsecureRepositories \\"true\\";" >> /target/etc/apt/apt.conf.d/99-offline
    - |
      echo "Acquire::AllowDowngradeToInsecureRepositories \\"true\\";" >> /target/etc/apt/apt.conf.d/99-offline
"""
    
    user_data_cmd = f"""cat > {remote_extract_dir}/nocloud/user-data << 'EOF'
{user_data}
EOF
# Copy to other locations
cp {remote_extract_dir}/nocloud/user-data {remote_extract_dir}/casper/nocloud/user-data
cp {remote_extract_dir}/nocloud/user-data {remote_extract_dir}/server/user-data
"""
    
    remote_command_func(user_data_cmd)
    
    # Create empty vendor-data files
    vendor_data_cmd = f"""
    echo "#cloud-config" > {remote_extract_dir}/nocloud/vendor-data
    echo "{{}}" >> {remote_extract_dir}/nocloud/vendor-data
    cp {remote_extract_dir}/nocloud/vendor-data {remote_extract_dir}/casper/nocloud/vendor-data
    cp {remote_extract_dir}/nocloud/vendor-data {remote_extract_dir}/server/vendor-data
    """
    
    remote_command_func(vendor_data_cmd)
    
    # Create preseed file
    preseed_content = """# Basic preseed file that triggers autoinstall
d-i auto-install/enable boolean true
d-i preseed/early_command string anna-install file-preseed
d-i file-preseed/url string file:///cdrom/nocloud/user-data
d-i apt-setup/disable-components string restricted,universe,multiverse
d-i apt-setup/no_mirror boolean true
d-i apt-setup/use_mirror boolean false
d-i apt-setup/security_host string
d-i apt-setup/services-select multiselect none
d-i pkgsel/update-policy select none
"""
    
    preseed_cmd = f"""cat > {remote_extract_dir}/preseed/ubuntu-server.seed << 'EOF'
{preseed_content}
EOF
"""
    
    remote_command_func(preseed_cmd)
    
    # 4. Repack ISO
    yield "Repacking ISO..."
    
    # Check available disk space in target directory before creating ISO
    target_dir = os.path.dirname(remote_crafted_iso)
    space_check_cmd = f"df -k {target_dir} | tail -1 | awk '{{print $4}}'"
    available_kb = remote_command_func(space_check_cmd)
    
    # Calculate the estimated ISO size (slightly larger than the source directory)
    size_cmd = f"du -sk {remote_extract_dir} | cut -f1"
    extract_size_kb = remote_command_func(size_cmd)
    
    try:
        available_space_kb = int(available_kb)
        needed_space_kb = int(extract_size_kb) * 1.1  # Add 10% buffer
        
        yield f"Creating ISO: Need approximately {needed_space_kb/1024:.2f} MB, have {available_space_kb/1024:.2f} MB available"
        
        # If not enough space in /var/www/html, try using /tmp instead
        if needed_space_kb > available_space_kb:
            yield f"Warning: Not enough space in {target_dir}. Checking alternative location..."
            
            alt_target_dir = "/tmp"
            alt_space_check_cmd = f"df -k {alt_target_dir} | tail -1 | awk '{{print $4}}'"
            alt_available_kb = remote_command_func(alt_space_check_cmd)
            alt_available_space_kb = int(alt_available_kb)
            
            if needed_space_kb > alt_available_space_kb:
                yield f"Error: Not enough space in {alt_target_dir} either ({alt_available_space_kb/1024:.2f} MB available)"
                yield "Cleaning up disk space to make room..."
                
                # Try to free up some space by removing old ISO files
                cleanup_cmd = f"find {target_dir} -name 'ubuntu*-autoinstall-*.iso' -type f -mtime +1 -delete"
                remote_command_func(cleanup_cmd)
                
                # Check space again
                space_check_cmd = f"df -k {target_dir} | tail -1 | awk '{{print $4}}'"
                available_kb = remote_command_func(space_check_cmd)
                available_space_kb = int(available_kb)
                
                yield f"After cleanup: {available_space_kb/1024:.2f} MB available in {target_dir}"
                
                if needed_space_kb > available_space_kb:
                    # Still not enough space, try making a smaller ISO
                    yield "Still not enough space. Will attempt to create a minimal ISO..."
                else:
                    yield f"Cleanup successful, proceeding with ISO creation in {target_dir}"
            else:
                # Use alternative location
                yield f"Using alternative location: {alt_target_dir}"
                remote_crafted_iso = f"{alt_target_dir}/{os.path.basename(remote_crafted_iso)}"
                yield f"New ISO path: {remote_crafted_iso}"
        
    except (ValueError, TypeError) as e:
        yield f"Warning: Could not parse disk space information: {e}. Proceeding anyway..."
    
    # Adjust repack commands based on Ubuntu version
    if version == "22":
        # For Ubuntu 22.04, we need to check for the actual location of the EFI boot image
        # Check if efi.img exists and get its path
        efi_img_check = f"find {remote_extract_dir} -name '*.img' | grep -i efi | head -1"
        efi_img_path = remote_command_func(efi_img_check).strip()
        
        # Always use a minimal command for Ubuntu 22.04 to avoid disk space issues
        xorriso_cmd = f"""
        xorriso -as mkisofs \\
        -o {remote_crafted_iso} \\
        -V "AUTO" \\
        -r \\
        {remote_extract_dir}
        """
        
        # Set fallback command - even simpler
        fallback_cmd = f"""
        xorriso -as mkisofs \\
        -o {remote_crafted_iso} \\
        -V "ISO" \\
        -r \\
        {remote_extract_dir}
        """
    else:
        # Check if isolinux.bin exists and get its path
        isolinux_check = f"find {remote_extract_dir} -name 'isolinux.bin' | head -1"
        isolinux_path = remote_command_func(isolinux_check).strip()
        
        if isolinux_path:
            isolinux_bin = os.path.relpath(isolinux_path, remote_extract_dir)
            isolinux_dir = os.path.dirname(isolinux_bin)
            boot_catalog = f"{isolinux_dir}/boot.cat"
            yield f"Found isolinux.bin at: {isolinux_bin}"
            
            # Check if we have BOOT directory extracted
            boot_check_cmd = f"if [ -d \"{remote_working_dir}/BOOT\" ]; then echo 'BOOT_EXISTS'; else echo 'NO_BOOT'; fi"
            boot_exists = remote_command_func(boot_check_cmd).strip()
            
            # Look for EFI boot image
            efi_img_check = f"find {remote_extract_dir} -name 'efi.img' | head -1"
            efi_img_path = remote_command_func(efi_img_check).strip()
            efi_path = ""
            if efi_img_path:
                efi_path = os.path.relpath(efi_img_path, remote_extract_dir)
                yield f"Found EFI boot image at: {efi_path}"
            
            if boot_exists == 'BOOT_EXISTS':
                # Complex command with BOOT files
                xorriso_cmd = f"""
                xorriso -as mkisofs -r \\
                -V "UBUNTU_AUTOINSTALL" \\
                -o {remote_crafted_iso} \\
                --grub2-mbr {remote_working_dir}/BOOT/1-Boot-NoEmul.img \\
                -partition_offset 16 \\
                --mbr-force-bootable \\
                -append_partition 2 28732ac11ff8d211ba4b00a0c93ec93b \\
                {remote_working_dir}/BOOT/2-Boot-NoEmul.img \\
                -appended_part_as_gpt \\
                -iso_mbr_part_type a2a0d0ebe5b9334487c068b6b72699c7 \\
                -c /{boot_catalog} \\
                -b /{isolinux_bin} \\
                -no-emul-boot -boot-load-size 4 -boot-info-table \\
                {remote_extract_dir}
                """
            elif efi_path:
                # Regular bootable ISO with EFI support
                xorriso_cmd = f"""
                xorriso -as mkisofs \\
                -o {remote_crafted_iso} \\
                -J -r -V "UBUNTU_AUTOINSTALL" \\
                -joliet-long \\
                -c /{boot_catalog} \\
                -b /{isolinux_bin} \\
                -no-emul-boot -boot-load-size 4 -boot-info-table \\
                -eltorito-alt-boot \\
                -e /{efi_path} \\
                -no-emul-boot \\
                -isohybrid-gpt-basdat \\
                {remote_extract_dir}
                """
            else:
                # Basic bootable ISO
                xorriso_cmd = f"""
                xorriso -as mkisofs \\
                -o {remote_crafted_iso} \\
                -J -r -V "UBUNTU_AUTOINSTALL" \\
                -joliet-long \\
                -c /{boot_catalog} \\
                -b /{isolinux_bin} \\
                -no-emul-boot -boot-load-size 4 -boot-info-table \\
                {remote_extract_dir}
                """
            
            # Fallback method for Ubuntu 20.04
            fallback_cmd = f"""
            xorriso -as mkisofs \\
            -o {remote_crafted_iso} \\
            -V "UBUNTUAUTO" \\
            -r -J \\
            {remote_extract_dir}
            """
        else:
            # Fallback method if isolinux.bin not found
            xorriso_cmd = f"""
            xorriso -as mkisofs \\
            -o {remote_crafted_iso} \\
            -V "UBUNTUAUTO" \\
            -r -J \\
            {remote_extract_dir}
            """
            
            fallback_cmd = xorriso_cmd
    
    try:
        yield "Running xorriso command..."
        remote_command_func(xorriso_cmd)
        yield f"ISO successfully repacked to {remote_crafted_iso}"
    except Exception:
        yield "Error with ISO repacking, trying fallback method..."
        # Fallback method
        remote_command_func(fallback_cmd)
        yield f"ISO successfully repacked using fallback method to {remote_crafted_iso}"
    
    # If ISO was created in an alternative location (/tmp), move it to /var/www/html for HTTP access
    if "/tmp/" in remote_crafted_iso:
        original_target = f"/var/www/html/{os.path.basename(remote_crafted_iso)}"
        yield f"Moving ISO from temporary location to {original_target}..."
        move_cmd = f"mv {remote_crafted_iso} {original_target}"
        move_result = remote_command_func(move_cmd)
        
        if move_result is None:
            yield f"Warning: Failed to move ISO to {original_target}, it will remain at {remote_crafted_iso}"
            # Try to make the ISO accessible via HTTP from its current location
            link_cmd = f"ln -sf {remote_crafted_iso} /var/www/html/{os.path.basename(remote_crafted_iso)}"
            link_result = remote_command_func(link_cmd)
            if link_result is None:
                yield f"Warning: Failed to create symbolic link. ISO may not be accessible via HTTP."
            else:
                remote_crafted_iso = original_target
                yield f"Created symbolic link to ISO at {original_target}"
        else:
            remote_crafted_iso = original_target
            yield f"ISO moved successfully to {original_target}"
    
    # 5. Return ISO information for iDRAC mounting
    yield f"ISO_READY:{remote_crafted_iso}"
    
    # Clean up
    remote_command_func(f"rm -rf {remote_extract_dir}")
    return remote_crafted_iso

def mount_iso_on_idrac(config, iso_url):
    """Mount the ISO on iDRAC and set boot options"""
    # Add safety checks for iDRAC parameters
    idrac_ip = config.get('idracIp')
    idrac_user = config.get('idracUser', 'root')
    idrac_password = config.get('idracPassword')
    
    # Validate required parameters
    if not idrac_ip or not idrac_password:
        yield "Error: Missing required iDRAC parameters (IP address or password)"
        return False
    
    # Create session
    yield "Creating iDRAC session..."
    session_url = f"https://{idrac_ip}/redfish/v1/SessionService/Sessions"
    headers = {'Content-Type': 'application/json'}
    payload = {"UserName": idrac_user, "Password": idrac_password}
    
    try:
        session = requests.post(session_url, json=payload, headers=headers, verify=False)
        
        if session.status_code != 201:
            yield f"Authentication Failed: {session.text}"
            return False
        
        token = session.headers['X-Auth-Token']
        session_uri = session.headers['Location']
        if session_uri.startswith("/"):
            session_uri = f"https://{idrac_ip}{session_uri}"
        
        headers['X-Auth-Token'] = token
        yield "Authenticated Successfully."
        
        # Check if ISO is already mounted
        vm_status_url = f"https://{idrac_ip}/redfish/v1/Managers/iDRAC.Embedded.1/VirtualMedia/CD"
        response = requests.get(vm_status_url, headers=headers, verify=False)
        if response.status_code == 200:
            vm_info = response.json()
            current_image = vm_info.get('Image', None)
            if current_image == iso_url:
                yield "ISO is already mounted."
            elif current_image:
                yield f"Another ISO is mounted: {current_image}. Unmounting..."
                unmount_url = f"https://{idrac_ip}/redfish/v1/Managers/iDRAC.Embedded.1/VirtualMedia/CD/Actions/VirtualMedia.EjectMedia"
                unmount_response = requests.post(unmount_url, headers=headers, verify=False)
                if unmount_response.status_code in [200, 204]:
                    yield "Previous ISO unmounted successfully."
                else:
                    yield f"Failed to unmount previous ISO: {unmount_response.text}"
            else:
                yield "No ISO currently mounted."
        else:
            yield f"Failed to check Virtual Media status: {response.text}"
        
        # Mount the ISO
        yield f"Mounting ISO: {iso_url}"
        vm_insert_url = f"https://{idrac_ip}/redfish/v1/Managers/iDRAC.Embedded.1/VirtualMedia/CD/Actions/VirtualMedia.InsertMedia"
        iso_payload = {
            "Image": iso_url,
            "Inserted": True,
            "WriteProtected": True
        }
        
        response = requests.post(vm_insert_url, json=iso_payload, headers=headers, verify=False)
        if response.status_code in [200, 204]:
            yield "ISO Mounted Successfully."
        else:
            yield f"Failed to Mount ISO: {response.text}"
            success = False
        
        # Set first boot device to Virtual CD/DVD
        yield "Setting boot device to Virtual CD/DVD..."
        attributes_url = f"https://{idrac_ip}/redfish/v1/Managers/iDRAC.Embedded.1/Attributes/"
        boot_payload = {
            "Attributes": {
                "ServerBoot.1.FirstBootDevice": "VCD-DVD"
            }
        }
        
        response = requests.patch(attributes_url, json=boot_payload, headers=headers, verify=False)
        if response.status_code in [200, 204]:
            yield "First Boot Device set to Virtual CD/DVD."
        else:
            yield f"Failed to set first boot device: {response.text}"
            success = False
        
        # Enable one-time boot
        yield "Enabling one-time boot for Virtual Media..."
        boot_once_payload = {
            "Attributes": {
                "VirtualMedia.1.BootOnce": "Enabled"
            }
        }
        
        response = requests.patch(attributes_url, json=boot_once_payload, headers=headers, verify=False)
        if response.status_code in [200, 204]:
            yield "One-Time Boot enabled for Virtual Media."
        else:
            yield f"Failed to enable one-time boot: {response.text}"
            success = False
        
        # Reboot the server
        yield "Rebooting server to start installation..."
        reset_url = f"https://{idrac_ip}/redfish/v1/Systems/System.Embedded.1/Actions/ComputerSystem.Reset"
        reboot_payload = {"ResetType": "ForceRestart"}
        response = requests.post(reset_url, json=reboot_payload, headers=headers, verify=False)
        
        if response.status_code in [200, 204]:
            yield "Server reboot initiated successfully."
            success = True
        else:
            yield f"Failed to reboot server: {response.text}"
            success = False
        
        # Close the session
        close_response = requests.delete(session_uri, headers=headers, verify=False)
        if close_response.status_code in [200, 204]:
            yield "Closed iDRAC session."
        else:
            yield f"Failed to close session: {close_response.text}"
        
        return success
    
    except requests.exceptions.RequestException as e:
        yield f"Error connecting to iDRAC: {str(e)}"
        return False 